var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="760">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="760">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1649966448594.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1649966448594-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-4812e376-cbac-4147-8d46-f22e9429f9c2" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Add a Task" width="360" height="760">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/4812e376-cbac-4147-8d46-f22e9429f9c2-1649966448594.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/4812e376-cbac-4147-8d46-f22e9429f9c2-1649966448594-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/4812e376-cbac-4147-8d46-f22e9429f9c2-1649966448594-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Bg" class="pie percentage richtext manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Paragraph"   datasizewidth="100.0%" datasizeheight="76.0px" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Bg_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_71" class="pie image firer click ie-background commentable non-processed" customid="Image_71"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="12.0" dataY="33.0"   alt="image" systemName="./images/d267453c-80fb-4d04-9926-85a8d7c817ff.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" fill="#FFFFFF" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph" class="pie richtext autofit firer ie-background commentable non-processed" customid="Add a Task"   datasizewidth="111.3px" datasizeheight="25.0px" dataX="43.0" dataY="32.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_0">Add a Task</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="214.0px" datasizeheight="29.0px" dataX="12.0" dataY="115.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Task title"   datasizewidth="72.0px" datasizeheight="20.0px" dataX="17.0" dataY="88.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Task title</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="Details"   datasizewidth="55.0px" datasizeheight="20.0px" dataX="17.0" dataY="168.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Details</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_17" class="pie image firer toggle ie-background commentable non-processed" customid="Image_17"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="247.0" dataY="118.0"   alt="image" systemName="./images/89f82d14-5a44-4b20-bc0f-6159e67312fe.svg" overlay="#35B736">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z" fill="#35B736" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_16" class="pie image firer click ie-background commentable non-processed" customid="Image_16"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="277.0" dataY="118.0"   alt="image" systemName="./images/d1257278-3269-4ebd-b163-1210ea05c979.svg" overlay="#E2202C">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" fill="#E2202C" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer click commentable non-processed" customid="Done"   datasizewidth="54.1px" datasizeheight="20.0px" dataX="220.0" dataY="487.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Done</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="pie richtext manualfit firer click commentable non-processed" customid="Cancel"   datasizewidth="61.5px" datasizeheight="20.0px" dataX="289.5" dataY="487.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Cancel</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="checkbox firer commentable non-processed unchecked" customid="Input"  datasizewidth="28.0px" datasizeheight="22.0px" dataX="94.0" dataY="654.0"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext manualfit firer commentable non-processed" customid="Mark as complete"   datasizewidth="209.5px" datasizeheight="20.0px" dataX="129.0" dataY="655.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Mark as complete</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_18" class="pie image firer toggle ie-background commentable non-processed" customid="Image_17"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="107.0" dataY="164.0"   alt="image" systemName="./images/4b769877-16fa-4605-a4f2-e96b275105a3.svg" overlay="#35B736">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z" fill="#35B736" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_20" class="pie image firer click ie-background commentable non-processed" customid="Image_16"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="149.5" dataY="164.0"   alt="image" systemName="./images/2e5ff54c-0b7c-4ba9-bbdc-1adf0099a7ad.svg" overlay="#E2202C">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" fill="#E2202C" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_7" class="pie richtext manualfit firer commentable hidden non-processed" customid="Saved!"   datasizewidth="68.2px" datasizeheight="20.0px" dataX="232.8" dataY="538.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Saved!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-input_text_area" class="group firer ie-background commentable non-processed" customid="input_text_area" datasizewidth="0.0px" datasizeheight="166.0px" >\
        <div id="s-Input_4" class="pie percentage textarea firer focusin focusout ie-background commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Input_4"  datasizewidth="95.0%" datasizeheight="166.0px" dataX="0.0" dataY="193.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><textarea   tabindex="-1" placeholder="Type something"></textarea></div></div></div>\
        <div id="s-Line_7" class="pie percentage rectangle manualfit firer commentable pin hpin-center non-processed-percentage non-processed-pin non-processed" customid="Line_7"   datasizewidth="95.0%" datasizeheight="1.0px" datasizewidthpx="342.0" datasizeheightpx="1.0" dataX="0.0" dataY="357.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Line_7_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Line_8" class="pie percentage rectangle manualfit firer commentable pin hpin-center non-processed-percentage non-processed-pin hidden non-processed" customid="Line_8"   datasizewidth="95.0%" datasizeheight="2.0px" datasizewidthpx="342.0" datasizeheightpx="2.0" dataX="0.0" dataY="357.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Line_8_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="30.8px" datasizeheight="30.0px" datasizewidthpx="30.773437499999943" datasizeheightpx="30.0" dataX="103.6" dataY="163.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="30.8px" datasizeheight="30.0px" datasizewidthpx="30.773437499999943" datasizeheightpx="30.0" dataX="146.1" dataY="163.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="30.8px" datasizeheight="30.0px" datasizewidthpx="30.773437499999943" datasizeheightpx="30.0" dataX="243.3" dataY="115.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="30.8px" datasizeheight="30.0px" datasizewidthpx="30.773437499999943" datasizeheightpx="30.0" dataX="274.0" dataY="115.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="63.3px" datasizeheight="25.0px" datasizewidthpx="63.2978515625" datasizeheightpx="25.0" dataX="215.0" dataY="484.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="63.3px" datasizeheight="25.0px" datasizewidthpx="63.2978515625" datasizeheightpx="25.0" dataX="287.7" dataY="484.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_126" class="pie image firer click ie-background commentable non-processed" customid="Image_126"  title="Tap to Speak" datasizewidth="55.0px" datasizeheight="55.0px" dataX="123.4" dataY="532.0"   alt="image" systemName="./images/65da3728-99b1-40ef-8fa6-fe63f77db68b.svg" overlay="#CB36E7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z" fill="#CB36E7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Ellipse" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse non-processed"   datasizewidth="86.0px" datasizeheight="79.0px" datasizewidthpx="86.0" datasizeheightpx="79.0" dataX="108.0" dataY="520.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse)">\
                          <ellipse id="s-Ellipse" class="pie ellipse shape non-processed-shape manualfit firer ie-background commentable hidden non-processed" customid="Ellipse" cx="43.0" cy="39.5" rx="43.0" ry="39.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse" class="clipPath">\
                          <ellipse cx="43.0" cy="39.5" rx="43.0" ry="39.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="Listening..."   datasizewidth="116.1px" datasizeheight="27.0px" dataX="108.0" dataY="603.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Listening...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="85.0px" datasizeheight="25.0px" datasizewidthpx="84.96289062499999" datasizeheightpx="25.0" dataX="9.0" dataY="85.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="85.0px" datasizeheight="25.0px" datasizewidthpx="84.96289062499999" datasizeheightpx="25.0" dataX="9.0" dataY="165.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_8" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="37.2px" datasizeheight="33.0px" datasizewidthpx="37.153564453125" datasizeheightpx="33.0" dataX="5.8" dataY="32.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;