var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="760">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="760">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1649966448594.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1649966448594-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1649966448594-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-76b016b0-dd56-430b-8b1b-691d588f724d" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Set Reminder" width="360" height="760">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/76b016b0-dd56-430b-8b1b-691d588f724d-1649966448594.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/76b016b0-dd56-430b-8b1b-691d588f724d-1649966448594-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/76b016b0-dd56-430b-8b1b-691d588f724d-1649966448594-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext autofit firer commentable non-processed" customid="Set a Time"   datasizewidth="106.4px" datasizeheight="25.0px" dataX="22.0" dataY="80.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Set a Time</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_71" class="pie image firer click ie-background commentable non-processed" customid="Image_71"   datasizewidth="40.0px" datasizeheight="41.0px" dataX="83.6" dataY="105.0"   alt="image" systemName="./images/6b59aa7c-f7ba-4f9d-9030-a1eda1db8f60.svg" overlay="#7D7D7D">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M7 14l5-5 5 5z" fill="#7D7D7D" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph" class="pie richtext manualfit firer ie-background commentable non-processed" customid="0"   datasizewidth="78.4px" datasizeheight="51.0px" dataX="64.4" dataY="159.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_0">0</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer ie-background commentable non-processed" customid="0"   datasizewidth="78.4px" datasizeheight="51.0px" dataX="161.0" dataY="159.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">0</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext manualfit firer ie-background commentable non-processed" customid=":"   datasizewidth="45.4px" datasizeheight="51.0px" dataX="133.5" dataY="159.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_70" class="pie image firer click ie-background commentable non-processed" customid="Image_70"   datasizewidth="36.0px" datasizeheight="36.0px" dataX="85.6" dataY="215.0"   alt="image" systemName="./images/e9c62ea5-158c-407e-b507-dd17d9132744.svg" overlay="#7D7D7D">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M7 10l5 5 5-5z" fill="#7D7D7D" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Hours"   datasizewidth="48.0px" datasizeheight="20.0px" dataX="80.3" dataY="262.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Hours</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Minutes"   datasizewidth="63.0px" datasizeheight="20.0px" dataX="188.5" dataY="262.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Minutes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="Days"   datasizewidth="41.0px" datasizeheight="20.0px" dataX="27.1" dataY="344.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Days</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="pie richtext manualfit firer toggle ie-background commentable non-processed" customid="M"   datasizewidth="48.0px" datasizeheight="58.0px" dataX="16.4" dataY="370.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">M</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="pie richtext manualfit firer toggle ie-background commentable non-processed" customid="T"   datasizewidth="48.0px" datasizeheight="58.0px" dataX="64.4" dataY="370.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">T</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="pie richtext manualfit firer toggle ie-background commentable non-processed" customid="W"   datasizewidth="48.0px" datasizeheight="58.0px" dataX="112.4" dataY="370.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">W</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_10" class="pie richtext manualfit firer toggle ie-background commentable non-processed" customid="TH"   datasizewidth="48.0px" datasizeheight="58.0px" dataX="160.4" dataY="370.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0">TH</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="pie richtext manualfit firer toggle ie-background commentable non-processed" customid="F"   datasizewidth="48.0px" datasizeheight="58.0px" dataX="208.4" dataY="370.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0">F</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="pie richtext manualfit firer toggle ie-background commentable non-processed" customid="S"   datasizewidth="48.0px" datasizeheight="58.0px" dataX="256.4" dataY="370.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0">S</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_13" class="pie richtext manualfit firer toggle ie-background commentable non-processed" customid="SU"   datasizewidth="48.0px" datasizeheight="58.0px" dataX="304.5" dataY="370.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_13_0">SU</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_17" class="pie richtext autofit firer commentable non-processed" customid="Set a Day"   datasizewidth="96.6px" datasizeheight="25.0px" dataX="27.1" dataY="307.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_17_0">Set a Day</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_18" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="Listening..."   datasizewidth="116.1px" datasizeheight="27.0px" dataX="112.4" dataY="598.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_18_0">Listening...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Bg" class="pie percentage richtext manualfit firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed" customid="Paragraph"   datasizewidth="100.0%" datasizeheight="76.0px" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Bg_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_19" class="pie richtext autofit firer ie-background commentable non-processed" customid="Set a Reminder"   datasizewidth="152.9px" datasizeheight="25.0px" dataX="43.0" dataY="32.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_19_0">Set a Reminder</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_74" class="pie image firer click ie-background commentable non-processed" customid="Image_71"   datasizewidth="24.0px" datasizeheight="24.0px" dataX="12.0" dataY="33.0"   alt="image" systemName="./images/fc949f02-4e20-4907-be2b-f60814671e23.svg" overlay="#FFFFFF">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" fill="#FFFFFF" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_75" class="pie image firer click ie-background commentable non-processed" customid="Image_71"   datasizewidth="40.0px" datasizeheight="41.0px" dataX="180.0" dataY="105.0"   alt="image" systemName="./images/ed36600c-4062-4224-8345-2e59fb14f228.svg" overlay="#7D7D7D">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M7 14l5-5 5 5z" fill="#7D7D7D" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_72" class="pie image firer click ie-background commentable non-processed" customid="Image_70"   datasizewidth="36.0px" datasizeheight="36.0px" dataX="182.2" dataY="215.0"   alt="image" systemName="./images/c9f6eb91-acea-44d4-8862-3bbcc7a1a78d.svg" overlay="#7D7D7D">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M7 10l5 5 5-5z" fill="#7D7D7D" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="30.1px" datasizeheight="46.0px" datasizewidthpx="30.13719940185547" datasizeheightpx="46.0" dataX="25.3" dataY="364.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="30.1px" datasizeheight="46.0px" datasizewidthpx="30.13719940185547" datasizeheightpx="46.0" dataX="73.3" dataY="364.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="34.5px" datasizeheight="46.0px" datasizewidthpx="34.46581268310547" datasizeheightpx="46.0" dataX="119.4" dataY="364.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="47.4px" datasizeheight="46.0px" datasizewidthpx="47.43505096435547" datasizeheightpx="46.0" dataX="161.0" dataY="364.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="30.1px" datasizeheight="46.0px" datasizewidthpx="30.13719940185547" datasizeheightpx="46.0" dataX="218.2" dataY="364.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="30.1px" datasizeheight="46.0px" datasizewidthpx="30.13719940185547" datasizeheightpx="46.0" dataX="265.4" dataY="364.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="48.0px" datasizeheight="46.0px" datasizewidthpx="48.0146484375" datasizeheightpx="46.0" dataX="304.5" dataY="364.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="75.1px" datasizeheight="46.0px" datasizewidthpx="75.13719940185547" datasizeheightpx="46.0" dataX="266.9" dataY="422.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_8" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="132.6px" datasizeheight="46.0px" datasizewidthpx="132.57300186157227" datasizeheightpx="46.0" dataX="10.2" dataY="296.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_8_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_10" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="132.6px" datasizeheight="34.0px" datasizewidthpx="132.57300186157227" datasizeheightpx="34.0" dataX="10.2" dataY="76.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_10_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_12" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="28.3px" datasizeheight="29.0px" datasizewidthpx="28.292255401611328" datasizeheightpx="29.0" dataX="89.4" dataY="111.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_12_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_13" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="28.3px" datasizeheight="29.0px" datasizewidthpx="28.292255401611328" datasizeheightpx="29.0" dataX="90.2" dataY="218.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_13_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_14" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="28.3px" datasizeheight="29.0px" datasizewidthpx="28.292255401611328" datasizeheightpx="29.0" dataX="186.0" dataY="218.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_14_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_15" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="28.3px" datasizeheight="29.0px" datasizewidthpx="28.292255401611328" datasizeheightpx="29.0" dataX="186.0" dataY="111.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_15_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_16" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="42.7px" datasizeheight="44.5px" datasizewidthpx="42.654296875" datasizeheightpx="44.49999999999994" dataX="5.0" dataY="22.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_16_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_126" class="pie image firer click ie-background commentable non-processed" customid="Image_126"  title="Tap to Speak" datasizewidth="55.0px" datasizeheight="55.0px" dataX="123.4" dataY="532.0"   alt="image" systemName="./images/82c84f12-c268-4290-9b42-d3aedd1de7b7.svg" overlay="#CB36E7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z" fill="#CB36E7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Ellipse" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse non-processed"   datasizewidth="86.0px" datasizeheight="79.0px" datasizewidthpx="86.0" datasizeheightpx="79.0" dataX="108.0" dataY="520.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse)">\
                          <ellipse id="s-Ellipse" class="pie ellipse shape non-processed-shape manualfit firer ie-background commentable hidden non-processed" customid="Ellipse" cx="43.0" cy="39.5" rx="43.0" ry="39.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse" class="clipPath">\
                          <ellipse cx="43.0" cy="39.5" rx="43.0" ry="39.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Paragraph_14" class="pie richtext manualfit firer click commentable non-processed" customid="Done"   datasizewidth="54.1px" datasizeheight="20.0px" dataX="277.4" dataY="435.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_14_0">Done</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_15" class="pie richtext manualfit firer commentable hidden non-processed" customid="Saved!"   datasizewidth="68.2px" datasizeheight="20.0px" dataX="270.3" dataY="487.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_15_0">Saved!</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;