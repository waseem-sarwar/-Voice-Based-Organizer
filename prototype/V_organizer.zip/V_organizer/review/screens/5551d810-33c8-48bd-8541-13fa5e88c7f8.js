var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="760">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="760">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1649966448594.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1649966448594-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-5551d810-33c8-48bd-8541-13fa5e88c7f8" class="pie screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Main Menu" width="360" height="760">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/5551d810-33c8-48bd-8541-13fa5e88c7f8-1649966448594.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/5551d810-33c8-48bd-8541-13fa5e88c7f8-1649966448594-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/5551d810-33c8-48bd-8541-13fa5e88c7f8-1649966448594-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph" class="pie richtext autofit firer ie-background commentable non-processed" customid="Voice-Based Organizer"   datasizewidth="185.4px" datasizeheight="82.0px" dataX="87.3" dataY="175.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_0">Voice-Based <br />Organizer</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Line" class="pie path firer ie-background commentable non-processed" customid="Line"   datasizewidth="200.0px" datasizeheight="1.0px" dataX="86.2" dataY="295.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="201.0" height="3.0" viewBox="86.1982421875 295.5 201.0 3.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line-5551d" d="M86.6982421875 297.0 L286.6982421875 297.0 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line-5551d" fill="none" stroke-width="2.0" stroke="#404040" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button" class="pie button multiline manualfit firer click ie-background commentable non-processed" customid="Take me in"   datasizewidth="100.0px" datasizeheight="49.0px" dataX="130.0" dataY="331.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_0">Take me in</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_126" class="pie image firer click ie-background commentable non-processed" customid="Image_126"  title="Tap to Speak" datasizewidth="55.0px" datasizeheight="55.0px" dataX="152.5" dataY="406.0"   alt="image" systemName="./images/b90f662d-c0c3-4a2c-a2f3-d61da6b371f2.svg" overlay="#CB36E7">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z" fill="#CB36E7" jimofill=" " /></svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="shapewrapper-s-Ellipse" customid="Ellipse" class="shapewrapper shapewrapper-s-Ellipse non-processed"   datasizewidth="86.0px" datasizeheight="79.0px" datasizewidthpx="86.0" datasizeheightpx="79.0" dataX="137.0" dataY="394.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse)">\
                          <ellipse id="s-Ellipse" class="pie ellipse shape non-processed-shape manualfit firer ie-background commentable hidden non-processed" customid="Ellipse" cx="43.0" cy="39.5" rx="43.0" ry="39.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse" class="clipPath">\
                          <ellipse cx="43.0" cy="39.5" rx="43.0" ry="39.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable hidden non-processed" customid="Listening..."   datasizewidth="116.1px" datasizeheight="27.0px" dataX="130.0" dataY="495.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Listening...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle" class="pie rectangle manualfit firer ie-background commentable hidden non-processed" customid="Rectangle"   datasizewidth="176.0px" datasizeheight="73.0px" datasizewidthpx="176.0" datasizeheightpx="73.0" dataX="91.0" dataY="315.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;