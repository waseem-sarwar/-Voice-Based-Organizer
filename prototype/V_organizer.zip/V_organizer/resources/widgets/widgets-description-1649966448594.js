	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Paragraph_1", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Image_71", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_71", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Drop Up", "s-Image_71"]; 

	widgets.descriptionMap[["s-Paragraph", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Paragraph_2", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_3", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Image_70", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_70", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Drop Down", "s-Image_70"]; 

	widgets.descriptionMap[["s-Paragraph_4", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Paragraph_5", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Paragraph_6", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Paragraph_7", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_8", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_13", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Paragraph_17", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_17"]; 

	widgets.descriptionMap[["s-Paragraph_18", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Paragraph_19", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Image_74", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_74", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Arrow Back", "s-Image_74"]; 

	widgets.descriptionMap[["s-Image_75", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_75", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Drop Up", "s-Image_75"]; 

	widgets.descriptionMap[["s-Image_72", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_72", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Drop Down", "s-Image_72"]; 

	widgets.descriptionMap[["s-Rectangle", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Rectangle_5", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Rectangle_6", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Rectangle_8", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_8"]; 

	widgets.descriptionMap[["s-Rectangle_10", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_10", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_10"]; 

	widgets.descriptionMap[["s-Rectangle_12", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_12", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_12"]; 

	widgets.descriptionMap[["s-Rectangle_13", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_13", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_13"]; 

	widgets.descriptionMap[["s-Rectangle_14", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_14", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_14"]; 

	widgets.descriptionMap[["s-Rectangle_15", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_15", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_15"]; 

	widgets.descriptionMap[["s-Rectangle_16", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_16", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Rectangle", "s-Rectangle_16"]; 

	widgets.descriptionMap[["s-Image_126", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_126", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Mic", "s-Image_126"]; 

	widgets.descriptionMap[["s-Ellipse", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Ellipse", "s-Ellipse"]; 

	widgets.descriptionMap[["s-Paragraph_14", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_15", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "76b016b0-dd56-430b-8b1b-691d588f724d"]] = ["Text", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Paragraph", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Line", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ""; 

			widgets.rootWidgetMap[["s-Line", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ["Line", "s-Line"]; 

	widgets.descriptionMap[["s-Button", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Image_126", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ""; 

			widgets.rootWidgetMap[["s-Image_126", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ["Mic", "s-Image_126"]; 

	widgets.descriptionMap[["s-Ellipse", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ["Ellipse", "s-Ellipse"]; 

	widgets.descriptionMap[["s-Paragraph_1", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Rectangle", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "5551d810-33c8-48bd-8541-13fa5e88c7f8"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Screen-bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Screen-bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Dark Background", "s-Screen-bg"]; 

	widgets.descriptionMap[["s-Softkeys-bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Softkeys-bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Square", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Square", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Circle", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Circle", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Triangle", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Triangle", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-Bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Empty screen", "s-Empty_screen"]; 

	widgets.descriptionMap[["s-more-vertical", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-more-vertical", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["More Vertical", "s-more-vertical"]; 

	widgets.descriptionMap[["s-Bg_status", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Bg_status", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-hour", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-hour", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Status bar light", "s-Status-bar"]; 

	widgets.descriptionMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Image_126", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_126", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Mic", "s-Image_126"]; 

	widgets.descriptionMap[["s-Ellipse", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Ellipse", "s-Ellipse"]; 

	widgets.descriptionMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Category", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Category", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["List Box", "s-Category"]; 

	widgets.descriptionMap[["s-Image_71", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image_71", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Arrow Back", "s-Image_71"]; 

	widgets.descriptionMap[["s-Rectangle", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Image_71", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_71", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Arrow Back", "s-Image_71"]; 

	widgets.descriptionMap[["s-Paragraph", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Input", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Paragraph_1", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Image_17", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_17", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Done", "s-Image_17"]; 

	widgets.descriptionMap[["s-Image_16", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_16", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Delete", "s-Image_16"]; 

	widgets.descriptionMap[["s-Paragraph_3", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_4", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Input_2", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Check Box", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Image_18", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_18", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Done", "s-Image_18"]; 

	widgets.descriptionMap[["s-Image_20", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_20", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Delete", "s-Image_20"]; 

	widgets.descriptionMap[["s-Paragraph_7", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Input_4", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text area", "s-input_text_area"]; 

	widgets.descriptionMap[["s-Line_7", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Line_7", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text area", "s-input_text_area"]; 

	widgets.descriptionMap[["s-Line_8", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Line_8", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text area", "s-input_text_area"]; 

	widgets.descriptionMap[["s-Rectangle", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Rectangle_3", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Rectangle_4", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_4", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle_4"]; 

	widgets.descriptionMap[["s-Rectangle_5", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_5", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle_5"]; 

	widgets.descriptionMap[["s-Image_126", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Image_126", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Mic", "s-Image_126"]; 

	widgets.descriptionMap[["s-Ellipse", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Ellipse", "s-Ellipse"]; 

	widgets.descriptionMap[["s-Paragraph_6", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Rectangle_6", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_6", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle_6"]; 

	widgets.descriptionMap[["s-Rectangle_7", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_7", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle_7"]; 

	widgets.descriptionMap[["s-Rectangle_8", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_8", "4812e376-cbac-4147-8d46-f22e9429f9c2"]] = ["Rectangle", "s-Rectangle_8"]; 

	