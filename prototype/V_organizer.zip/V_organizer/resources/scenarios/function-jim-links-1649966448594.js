(function(window, undefined) {

  var jimLinks = {
    "76b016b0-dd56-430b-8b1b-691d588f724d" : {
      "Image_74" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "5551d810-33c8-48bd-8541-13fa5e88c7f8" : {
      "Button" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Softkeys-bg" : [
        "4812e376-cbac-4147-8d46-f22e9429f9c2",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d"
      ],
      "Square" : [
        "4812e376-cbac-4147-8d46-f22e9429f9c2",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d"
      ],
      "Circle" : [
        "4812e376-cbac-4147-8d46-f22e9429f9c2",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d"
      ],
      "Triangle" : [
        "4812e376-cbac-4147-8d46-f22e9429f9c2",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d"
      ],
      "Bg" : [
        "4812e376-cbac-4147-8d46-f22e9429f9c2",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d"
      ],
      "Bg_status" : [
        "4812e376-cbac-4147-8d46-f22e9429f9c2",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d"
      ],
      "hour" : [
        "4812e376-cbac-4147-8d46-f22e9429f9c2",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d"
      ],
      "Paragraph_1" : [
        "76b016b0-dd56-430b-8b1b-691d588f724d"
      ],
      "Paragraph_2" : [
        "4812e376-cbac-4147-8d46-f22e9429f9c2",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "76b016b0-dd56-430b-8b1b-691d588f724d",
        "4812e376-cbac-4147-8d46-f22e9429f9c2"
      ],
      "Image_71" : [
        "5551d810-33c8-48bd-8541-13fa5e88c7f8"
      ]
    },
    "4812e376-cbac-4147-8d46-f22e9429f9c2" : {
      "Image_71" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Paragraph_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);